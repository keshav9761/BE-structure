const express = require('express');
const app = express();
const webSocket = require('express-ws');
const PORT = 9001;
webSocket(app)

let location = 1;
app.ws('/echo', (ws, req) => {

    ws.on('message', (message) => {
      console.log('Received from Mobile', message);
      location = message;
    });
    
});

let lat = 28.6872974, lng = 77.4822982
app.ws('/echoLocation', (ws, req) => {

  // ws.on('message', (message) => {
    setInterval(() => {
      // console.log('Send to Web App:', location);
      lat = lat + 0.0000100
      lng = lng + 0.0000100
      ws.send(JSON.stringify({ lat, lng }))
    }, 3000);
  // });
  
});

app.listen(PORT, () => {
    console.error('SOCKET Server is running on port http://localhost:9001')
});
